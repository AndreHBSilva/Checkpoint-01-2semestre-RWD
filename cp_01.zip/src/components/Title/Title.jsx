import React from 'react';
import './Title.css';

export default function Title() {

  return(
    <div>
      <h1 className="post__title">Quais são os sintomas da variante Delta da Covid-19? Teste seus conhecimentos.</h1>
    </div>
  )
}